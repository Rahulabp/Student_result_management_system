from django.apps import AppConfig


class srmsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'srmsApp'
