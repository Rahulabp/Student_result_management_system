Student-Results-Management-System
This project is a web-based application built with Python and the Django Framework. Certain school students or student parents can access the application's online platform to view the student's academic performance. The source code for this project is a Django version. This project has functionalities and features that are user-friendly. 
The management oversees the system's important lists, including the student list and the outcomes. The list of Classes, Subjects, Students, and Results can be conveniently stored and retrieved by administration users. Parents and students only need to pick the student's name for the system to display all of the student's academic record records. They can then select the list item to bring up a pop-up modal that shows the student's academic results details if they want all the specifics of the result. We have admin login. And anyone can view result using name only

Techstack
    Python
    Django
    SQLite3
    HTML
    CSS
    JavaScript
    jQuery
    Ajax
   
    

